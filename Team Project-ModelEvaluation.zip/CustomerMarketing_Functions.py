# -*- coding: utf-8 -*-
"""
Created on Mon Nov 22 22:52:45 2021

@author: maryam nouri
"""
import numpy as np
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib import colors
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import pickle
from yellowbrick.cluster import KElbowVisualizer
from google.cloud import storage
from io import BytesIO


def MNreadCSVfromGCPBucket (jasonfilepath,Bucket_name,filename):

    storage_client=storage.Client.from_service_account_json(jasonfilepath)
    
    Bucket_name=Bucket_name
    bucket=storage_client.get_bucket(Bucket_name)
    # filename=list(bucket.list_blobs(prefix=''))
    # for name in filename:
    #   print(name)
    
    blop=bucket.blob( filename)
    rawdata=blop.download_as_string()
    data=pd.read_csv(BytesIO(rawdata),encoding='utf-8')
    return data


def MNpreprocessing(rawdata,scalerpath='',iteration=1,agecap=95,incomecap=600000,scaler=False,debug=False):
    data=rawdata.copy()
#Data cleaning    ==============================================================
    data = data.dropna()  
    if debug:   print("The total number of data-points after removing missing values are:", len(data))
#Feature Engineering   ========================================================
    data["Dt_Customer"] = pd.to_datetime(data["Dt_Customer"])
    dates = []
    for i in data["Dt_Customer"]:
        i = i.date()
        dates.append(i)  
    days = []
    d1 = max(dates) #taking it to be the newest customer
    for i in dates:
        delta = d1 - i
        days.append(delta)
    data["Customer_For"] = days
    data["Customer_For"] = pd.to_numeric(data["Customer_For"], errors="coerce")
    #Age of customer today 
    currentyear=datetime.now().year
    data["Age"] = currentyear-data["Year_Birth"]
    #Total spendings on various items
    data["Spent"] = data["MntWines"]+ data["MntFruits"]+ data["MntMeatProducts"]+ data["MntFishProducts"]+ data["MntSweetProducts"]+ data["MntGoldProds"]
    #Deriving living situation by marital status"Alone"
    data["Living_With"]=data["Marital_Status"].replace({"Married":"Partner", "Together":"Partner", "Absurd":"Alone", "Widow":"Alone", "YOLO":"Alone", "Divorced":"Alone", "Single":"Alone"})
    #Feature indicating total children living in the household
    data["Children"]=data["Kidhome"]+data["Teenhome"]
    #Feature for total members in the householde
    data["Family_Size"] = data["Living_With"].replace({"Alone": 1, "Partner":2})+ data["Children"]
    #Feature pertaining parenthood
    data["Is_Parent"] = np.where(data.Children> 0, 1, 0)
    #Segmenting education levels in three groups
    data["Education"]=data["Education"].replace({"Basic":"Undergraduate","2n Cycle":"Undergraduate", "Graduation":"Graduate", "Master":"Postgraduate", "PhD":"Postgraduate"})
    #For clarity
    data=data.rename(columns={"MntWines": "Wines","MntFruits":"Fruits","MntMeatProducts":"Meat","MntFishProducts":"Fish","MntSweetProducts":"Sweets","MntGoldProds":"Gold"})
    #Dropping some of the redundant features
    to_drop = ["Marital_Status", "Dt_Customer", "Z_CostContact", "Z_Revenue", "Year_Birth", "ID"]
    data = data.drop(to_drop, axis=1)

    #Dropping the outliers by setting a cap on Age and income. 
    data = data[(data["Age"]<agecap)]
    data = data[(data["Income"]<incomecap)]
    #Get list of categorical variables and change to numeric
    s = (data.dtypes == 'object')
    object_cols = list(s[s].index)
    LE=LabelEncoder()
    for i in object_cols:
        data[i]=data[[i]].apply(LE.fit_transform)
    
    # dropping promotions columns
    cols_del = ['AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1','AcceptedCmp2', 'Complain', 'Response']
    data = data.drop(cols_del, axis=1)  
    
    #Scaling
    if scaler:
        with open(scalerpath, "rb") as f:
            scaler= pickle.load(f) 
            scaled_data = pd.DataFrame(scaler.transform(data),index=data.index,columns= data.columns )        
    else:
        scaler = StandardScaler()
        scaler.fit(data)
        scaled_data = pd.DataFrame(scaler.transform(data),index=data.index,columns= data.columns ) 
        with open('scaler'+str(iteration)+'.pkl', "wb") as f:
            pickle.dump(scaler, f)
    if debug:

        sns.set(rc={"axes.facecolor":"#FFF9ED","figure.facecolor":"#FFF9ED"})
        pallet = ["#682F2F", "#9E726F", "#D6B2B1", "#B9C0C9", "#9F8A78", "#F3AB60"]
        cmap = colors.ListedColormap(["#682F2F", "#9E726F", "#D6B2B1", "#B9C0C9", "#9F8A78", "#F3AB60"])
        #Plotting following features
        To_Plot = [ "Income", "Recency", "Customer_For", "Age", "Spent", "Is_Parent"]
        print("Reletive Plot Of Some Selected Features: A Data Subset")
        plt.figure()
        sns.pairplot(data[To_Plot], hue= "Is_Parent",palette= (["#682F2F","#F3AB60"]))
        #Taking hue 
        plt.show()
    
    return data,scaled_data

#===================================================================================================================

def MNclustermodel(data,ncluster=4,maxcluster=10,iteration=1,findnumcluster=False,debug=False):
    
    if findnumcluster:
       Elbow_M = KElbowVisualizer(KMeans(), k=maxcluster,locate_elbow=True)
       Elbow_M.fit(data)
       if Elbow_M.elbow_value_< ncluster:
           ncluster=Elbow_M.elbow_value_ 
           
       if debug:    Elbow_M.show()

    model = KMeans(n_clusters=ncluster)
    clusterprediction=model.fit(data)
    
    data['Clusters']=clusterprediction.labels_
    with open('model'+str(iteration)+'.pkl', "wb") as f:
        pickle.dump(model, f)

    if debug:

            #Plotting countplot of clusters
            pal = ["#682F2F","#B9C0C9", "#9F8A78","#F3AB60"]
            pl = sns.countplot(x=data["Clusters"], palette= pal)
            pl.set_title("Distribution Of The Clusters")
            plt.show()
            
            pl = sns.scatterplot(data = data,x=data["Spent"], y=data["Income"],hue=data["Clusters"], palette= pal)
            pl.set_title("Cluster's Profile Based On Income And Spending")
            plt.legend()
            plt.show()
            
            plt.figure()
            pl=sns.swarmplot(x=data["Clusters"], y=data["Spent"], color= "#CBEDDD", alpha=0.5 )
            pl=sns.boxenplot(x=data["Clusters"], y=data["Spent"], palette=pal)
            plt.show()        
    return data,model 

    
def MNpredict(modelpath, data):
    
    with open(modelpath, "rb") as f:
        model = pickle.load(f)        
    clusterprediction=model.predict(data) 
    data['Clusters']=clusterprediction
    
    return data
