# -*- coding: utf-8 -*-
"""
Created on Mon Nov 22 19:00:44 2021

@author: maryam nouri

CloudComputingfinalprojectipynb
 
"""
#Importing the Libraries
from CustomerMarketing_Functions import *
from sklearn.model_selection import train_test_split



# Flags and inputs ========================================================================
# data config
jasonfilepath=''
Bucket_name=''
filename=''
cloud=False         # read data from gcp bucket  
local=True         # read data from local file

# model config
debug=True
agecap=90
incomecap=600000
maxcluster=10
numcluster=4                       # number of clusters
iteration=1                        # use for name of files
findnumcluster=False               # True if model find best number of cluster otherwise False


#Loading data  =====================================================================================
if local:
    data=pd.read_csv('marketing_campaign.csv',sep='\t')
    train_data, test_data= train_test_split(data,  test_size=0.10, random_state=1)  # just to create a sample train data
    if debug:  print("The total number of data-points are:", len(data))
elif cloud:
    data=MNreadCSVfromGCPBucket (jasonfilepath,Bucket_name,filename)    
    train_data, test_data= train_test_split(data,  test_size=0.10, random_state=1)
    if debug:  print("The total number of data-points are:", len(data))

# training model =================================================================================
preprocessdata,scaled_data=MNpreprocessing(train_data,iteration=iteration,agecap=agecap,incomecap=incomecap,scaler=False,debug=debug)
clusterdata,model=MNclustermodel(scaled_data,ncluster=numcluster,maxcluster=maxcluster,iteration=iteration,findnumcluster=findnumcluster,debug=debug)
# merge data
finaldata=pd.merge(train_data,clusterdata[['Clusters']],how='left',left_index=True, right_index=True)






    

