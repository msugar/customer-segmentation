# -*- coding: utf-8 -*-
"""
Created on Mon Nov 22 22:50:34 2021

@author: maryam nouri
"""
from CustomerMarketing_Functions import *
from sklearn.model_selection import train_test_split


# Flags and inputs ========================================================================

# data config
jasonfilepath=''
Bucket_name=''
filename=''
cloud=False         # read data from gcp bucket  
local=True         # read data from local file

# model config
debug=True
agecap=90
incomecap=600000
scalerpath='scaler1.pkl'
modelpath='model1.pkl'



# load data=================================================================
#Loading data  =====================================================================================
if local:
    data=pd.read_csv('marketing_campaign.csv',sep='\t')
    train_data, test_data= train_test_split(data,  test_size=0.10, random_state=1)  # just to create a sample test data
    if debug:  print("The total number of data-points are:", len(data))
elif cloud:
    data=MNreadCSVfromGCPBucket (jasonfilepath,Bucket_name,filename)    
    train_data, test_data= train_test_split(data,  test_size=0.10, random_state=1)
    if debug:  print("The total number of data-points are:", len(data))


# prediction ===============================================================================
preprocessdata,scaled_data=MNpreprocessing(test_data,scalerpath=scalerpath,agecap=agecap,incomecap=incomecap,scaler=True,debug=debug)
clusterdata= MNpredict(modelpath=modelpath,data= scaled_data)
finaldata=pd.merge(test_data,clusterdata[['Clusters']],how='left',left_index=True, right_index=True)
